package com.pa.jk.pay.service;

import com.pa.jk.pay.bean.OrderInfo;

public interface OrderInfoXmlService {
	public OrderInfo getOrderInfoBySellerId(long id);
}
