package com.pa.jk.pay.config;

public class OrderInfoConstants {
	public static final String ORDER_INFO_REDIS_KEY_PIX = "O_";// 订单redis缓存key前缀
}
