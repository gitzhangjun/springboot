package com.pa.jk.pay.remote.parameter;

public interface ReqParas {
	String toJson();
}
