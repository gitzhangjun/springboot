package com.pa.jk.pay.controller.resources;

import org.springframework.stereotype.Service;

/**
 * API 异常处理层
 * 
 * @author zhangjun19
 *
 */
@Service("orderInfoResources")
public class OrderInfoResources {
	//TODO ExcepFactor
}
